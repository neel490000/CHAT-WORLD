
const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);
const multer = require("multer");
const path = require("path");
const fs = require("fs");

app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

app.post("/upload", upload.single("image"), (req, res) => {
  res.json({ imageUrl: "/uploads/" + req.file.filename });
});

io.on("connection", (socket) => {
  socket.on("join", ({ username, room }) => {
    socket.username = username;
    socket.room = room;
    socket.join(room);
    io.to(room).emit("message", { user: "System", text: `${username} joined ${room}` });
  });

  socket.on("chat message", (msg) => {
    io.to(socket.room).emit("message", { user: socket.username, text: msg });
  });

  socket.on("image", (url) => {
    io.to(socket.room).emit("image", { user: socket.username, url });
  });
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

http.listen(3000, () => {
  console.log("Server is running on http://localhost:3000");
});
